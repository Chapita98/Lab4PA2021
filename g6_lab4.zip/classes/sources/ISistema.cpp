#include "./../headers/ISistema.h"
ISistema::~ISistema(){}