#ifndef TIPO_H
#define TIPO_H
enum Tipo : int
{
    TEORICO=1,
    PRACTICO,
    MONITOREO
};
#endif
