Eugenio Perdomo 
    eugenio.perdomo@estudiantes.utec.edu.uy
Lucia Bentancur
    lucia.bentancur@estudiantes.utec.edu.uy
Virginia Diaz
    virginia.diaz.a@estudiantes.utec.edu.uy
Diego Cardinal
    dierodiero@gmail.com / diego.cardinal@utec.edu.uy


Con respecto a las contrasenias para docentes y estudiantes, todas son el numero 1


-Instrucciones para uso de archivo Makefile

1 - Abrir la terminal como root
2 - Posicionarse en la carpeta donde estar los archivos .cpp y .h
3 - Ejecutar comando:    'chmod +x Makefile.sh'     (o bien    'chmod 777 Makefile.sh')
4 - Asegurarse que no existan archivos .o antiguos con el comando:    'make clean'
5 - Crear archivos .o con el comando:    'make'
6 - Ejecutar programa con el comando:    './Lab0PA
7 - Una vez usado el programa, limpiar los archivos .o creados con el comando:    'make clean'
extra - Hacer 'make rebuild' (hace automaticamente  'make clean', y despues 'make')
